﻿namespace CalculadoraMetodosNumericos
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtErrorEB = new System.Windows.Forms.NumericUpDown();
            this.txtVelocidadB = new System.Windows.Forms.NumericUpDown();
            this.txtTiempoB = new System.Windows.Forms.NumericUpDown();
            this.txtMasaB = new System.Windows.Forms.NumericUpDown();
            this.txtErrorAB = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtIteracionesB = new System.Windows.Forms.TextBox();
            this.txtResultadoB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnCalcularB = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txtErrorEPF = new System.Windows.Forms.NumericUpDown();
            this.txtVelocidadPF = new System.Windows.Forms.NumericUpDown();
            this.txtTiempoPF = new System.Windows.Forms.NumericUpDown();
            this.txtMasaPF = new System.Windows.Forms.NumericUpDown();
            this.btnCalcPF = new System.Windows.Forms.Button();
            this.txtErrorAPF = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtIteracionesPF = new System.Windows.Forms.TextBox();
            this.txtResultadoPF = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnCalcularPF = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.txtErrorES = new System.Windows.Forms.NumericUpDown();
            this.txtVelocidadS = new System.Windows.Forms.NumericUpDown();
            this.txtTiempoS = new System.Windows.Forms.NumericUpDown();
            this.txtMasaS = new System.Windows.Forms.NumericUpDown();
            this.btnCalcS = new System.Windows.Forms.Button();
            this.txtErrorAS = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtIteracionesS = new System.Windows.Forms.TextBox();
            this.txtResultadoS = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.btnCalcularS = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtC1B = new System.Windows.Forms.NumericUpDown();
            this.txtC2B = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCPF = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.txtC1S = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.txtC2S = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtErrorEB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVelocidadB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTiempoB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMasaB)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtErrorEPF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVelocidadPF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTiempoPF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMasaPF)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtErrorES)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVelocidadS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTiempoS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMasaS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtC1B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtC2B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCPF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtC1S)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtC2S)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(13, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(330, 357);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.txtC2B);
            this.tabPage1.Controls.Add(this.txtC1B);
            this.tabPage1.Controls.Add(this.txtErrorEB);
            this.tabPage1.Controls.Add(this.txtVelocidadB);
            this.tabPage1.Controls.Add(this.txtTiempoB);
            this.tabPage1.Controls.Add(this.txtMasaB);
            this.tabPage1.Controls.Add(this.txtErrorAB);
            this.tabPage1.Controls.Add(this.label31);
            this.tabPage1.Controls.Add(this.txtIteracionesB);
            this.tabPage1.Controls.Add(this.txtResultadoB);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.btnCalcularB);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(322, 331);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Bisección";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtErrorEB
            // 
            this.txtErrorEB.DecimalPlaces = 10;
            this.txtErrorEB.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.txtErrorEB.Location = new System.Drawing.Point(128, 106);
            this.txtErrorEB.Name = "txtErrorEB";
            this.txtErrorEB.Size = new System.Drawing.Size(120, 20);
            this.txtErrorEB.TabIndex = 23;
            // 
            // txtVelocidadB
            // 
            this.txtVelocidadB.DecimalPlaces = 10;
            this.txtVelocidadB.Location = new System.Drawing.Point(128, 77);
            this.txtVelocidadB.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtVelocidadB.Name = "txtVelocidadB";
            this.txtVelocidadB.Size = new System.Drawing.Size(120, 20);
            this.txtVelocidadB.TabIndex = 22;
            // 
            // txtTiempoB
            // 
            this.txtTiempoB.DecimalPlaces = 10;
            this.txtTiempoB.Location = new System.Drawing.Point(128, 45);
            this.txtTiempoB.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtTiempoB.Name = "txtTiempoB";
            this.txtTiempoB.Size = new System.Drawing.Size(120, 20);
            this.txtTiempoB.TabIndex = 21;
            // 
            // txtMasaB
            // 
            this.txtMasaB.DecimalPlaces = 10;
            this.txtMasaB.Location = new System.Drawing.Point(128, 11);
            this.txtMasaB.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtMasaB.Name = "txtMasaB";
            this.txtMasaB.Size = new System.Drawing.Size(120, 20);
            this.txtMasaB.TabIndex = 20;
            // 
            // txtErrorAB
            // 
            this.txtErrorAB.Location = new System.Drawing.Point(128, 271);
            this.txtErrorAB.Name = "txtErrorAB";
            this.txtErrorAB.ReadOnly = true;
            this.txtErrorAB.Size = new System.Drawing.Size(100, 20);
            this.txtErrorAB.TabIndex = 19;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(6, 272);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(92, 13);
            this.label31.TabIndex = 18;
            this.label31.Text = "Error aproximado: ";
            // 
            // txtIteracionesB
            // 
            this.txtIteracionesB.Location = new System.Drawing.Point(128, 244);
            this.txtIteracionesB.Name = "txtIteracionesB";
            this.txtIteracionesB.ReadOnly = true;
            this.txtIteracionesB.Size = new System.Drawing.Size(100, 20);
            this.txtIteracionesB.TabIndex = 13;
            // 
            // txtResultadoB
            // 
            this.txtResultadoB.Location = new System.Drawing.Point(128, 218);
            this.txtResultadoB.Name = "txtResultadoB";
            this.txtResultadoB.ReadOnly = true;
            this.txtResultadoB.Size = new System.Drawing.Size(100, 20);
            this.txtResultadoB.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 247);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Las iteraciones fueron:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 221);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "El valor es:";
            // 
            // btnCalcularB
            // 
            this.btnCalcularB.Location = new System.Drawing.Point(239, 300);
            this.btnCalcularB.Name = "btnCalcularB";
            this.btnCalcularB.Size = new System.Drawing.Size(75, 23);
            this.btnCalcularB.TabIndex = 10;
            this.btnCalcularB.Text = "Calcular";
            this.btnCalcularB.UseVisualStyleBackColor = true;
            this.btnCalcularB.Click += new System.EventHandler(this.btnCalcularB_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Error estimado:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Velocidad:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Tiempo:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Masa:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.txtCPF);
            this.tabPage2.Controls.Add(this.txtErrorEPF);
            this.tabPage2.Controls.Add(this.txtVelocidadPF);
            this.tabPage2.Controls.Add(this.txtTiempoPF);
            this.tabPage2.Controls.Add(this.txtMasaPF);
            this.tabPage2.Controls.Add(this.btnCalcPF);
            this.tabPage2.Controls.Add(this.txtErrorAPF);
            this.tabPage2.Controls.Add(this.label32);
            this.tabPage2.Controls.Add(this.txtIteracionesPF);
            this.tabPage2.Controls.Add(this.txtResultadoPF);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.btnCalcularPF);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(322, 331);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Punto fijo";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // txtErrorEPF
            // 
            this.txtErrorEPF.DecimalPlaces = 10;
            this.txtErrorEPF.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.txtErrorEPF.Location = new System.Drawing.Point(128, 102);
            this.txtErrorEPF.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtErrorEPF.Name = "txtErrorEPF";
            this.txtErrorEPF.Size = new System.Drawing.Size(120, 20);
            this.txtErrorEPF.TabIndex = 41;
            // 
            // txtVelocidadPF
            // 
            this.txtVelocidadPF.DecimalPlaces = 10;
            this.txtVelocidadPF.Location = new System.Drawing.Point(128, 73);
            this.txtVelocidadPF.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtVelocidadPF.Name = "txtVelocidadPF";
            this.txtVelocidadPF.Size = new System.Drawing.Size(120, 20);
            this.txtVelocidadPF.TabIndex = 40;
            // 
            // txtTiempoPF
            // 
            this.txtTiempoPF.DecimalPlaces = 10;
            this.txtTiempoPF.Location = new System.Drawing.Point(128, 41);
            this.txtTiempoPF.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtTiempoPF.Name = "txtTiempoPF";
            this.txtTiempoPF.Size = new System.Drawing.Size(120, 20);
            this.txtTiempoPF.TabIndex = 39;
            // 
            // txtMasaPF
            // 
            this.txtMasaPF.DecimalPlaces = 10;
            this.txtMasaPF.Location = new System.Drawing.Point(128, 9);
            this.txtMasaPF.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtMasaPF.Name = "txtMasaPF";
            this.txtMasaPF.Size = new System.Drawing.Size(120, 20);
            this.txtMasaPF.TabIndex = 38;
            // 
            // btnCalcPF
            // 
            this.btnCalcPF.Location = new System.Drawing.Point(241, 296);
            this.btnCalcPF.Name = "btnCalcPF";
            this.btnCalcPF.Size = new System.Drawing.Size(75, 23);
            this.btnCalcPF.TabIndex = 37;
            this.btnCalcPF.Text = "Calcular";
            this.btnCalcPF.UseVisualStyleBackColor = true;
            this.btnCalcPF.Click += new System.EventHandler(this.btnCalcPF_Click);
            // 
            // txtErrorAPF
            // 
            this.txtErrorAPF.Location = new System.Drawing.Point(129, 267);
            this.txtErrorAPF.Name = "txtErrorAPF";
            this.txtErrorAPF.ReadOnly = true;
            this.txtErrorAPF.Size = new System.Drawing.Size(100, 20);
            this.txtErrorAPF.TabIndex = 36;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(7, 268);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(92, 13);
            this.label32.TabIndex = 35;
            this.label32.Text = "Error aproximado: ";
            // 
            // txtIteracionesPF
            // 
            this.txtIteracionesPF.Location = new System.Drawing.Point(128, 238);
            this.txtIteracionesPF.Name = "txtIteracionesPF";
            this.txtIteracionesPF.ReadOnly = true;
            this.txtIteracionesPF.Size = new System.Drawing.Size(100, 20);
            this.txtIteracionesPF.TabIndex = 30;
            // 
            // txtResultadoPF
            // 
            this.txtResultadoPF.Location = new System.Drawing.Point(128, 212);
            this.txtResultadoPF.Name = "txtResultadoPF";
            this.txtResultadoPF.ReadOnly = true;
            this.txtResultadoPF.Size = new System.Drawing.Size(100, 20);
            this.txtResultadoPF.TabIndex = 29;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(7, 241);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(114, 13);
            this.label15.TabIndex = 18;
            this.label15.Text = "Las iteraciones fueron:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 215);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 13);
            this.label16.TabIndex = 28;
            this.label16.Text = "El valor es:";
            // 
            // btnCalcularPF
            // 
            this.btnCalcularPF.Location = new System.Drawing.Point(440, 241);
            this.btnCalcularPF.Name = "btnCalcularPF";
            this.btnCalcularPF.Size = new System.Drawing.Size(75, 23);
            this.btnCalcularPF.TabIndex = 27;
            this.btnCalcularPF.Text = "Calcular";
            this.btnCalcularPF.UseVisualStyleBackColor = true;
            this.btnCalcularPF.Click += new System.EventHandler(this.btnCalcularPF_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 104);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 13);
            this.label17.TabIndex = 25;
            this.label17.Text = "Error estimado:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 75);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(57, 13);
            this.label18.TabIndex = 23;
            this.label18.Text = "Velocidad:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 43);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(45, 13);
            this.label19.TabIndex = 21;
            this.label19.Text = "Tiempo:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 11);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(36, 13);
            this.label20.TabIndex = 20;
            this.label20.Text = "Masa:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.txtC2S);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.txtC1S);
            this.tabPage3.Controls.Add(this.txtErrorES);
            this.tabPage3.Controls.Add(this.txtVelocidadS);
            this.tabPage3.Controls.Add(this.txtTiempoS);
            this.tabPage3.Controls.Add(this.txtMasaS);
            this.tabPage3.Controls.Add(this.btnCalcS);
            this.tabPage3.Controls.Add(this.txtErrorAS);
            this.tabPage3.Controls.Add(this.label33);
            this.tabPage3.Controls.Add(this.txtIteracionesS);
            this.tabPage3.Controls.Add(this.txtResultadoS);
            this.tabPage3.Controls.Add(this.label25);
            this.tabPage3.Controls.Add(this.label26);
            this.tabPage3.Controls.Add(this.btnCalcularS);
            this.tabPage3.Controls.Add(this.label27);
            this.tabPage3.Controls.Add(this.label28);
            this.tabPage3.Controls.Add(this.label29);
            this.tabPage3.Controls.Add(this.label30);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(322, 331);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Secante";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // txtErrorES
            // 
            this.txtErrorES.DecimalPlaces = 10;
            this.txtErrorES.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.txtErrorES.Location = new System.Drawing.Point(128, 102);
            this.txtErrorES.Name = "txtErrorES";
            this.txtErrorES.Size = new System.Drawing.Size(120, 20);
            this.txtErrorES.TabIndex = 41;
            // 
            // txtVelocidadS
            // 
            this.txtVelocidadS.DecimalPlaces = 10;
            this.txtVelocidadS.Location = new System.Drawing.Point(128, 73);
            this.txtVelocidadS.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtVelocidadS.Name = "txtVelocidadS";
            this.txtVelocidadS.Size = new System.Drawing.Size(120, 20);
            this.txtVelocidadS.TabIndex = 40;
            // 
            // txtTiempoS
            // 
            this.txtTiempoS.DecimalPlaces = 10;
            this.txtTiempoS.Location = new System.Drawing.Point(128, 41);
            this.txtTiempoS.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtTiempoS.Name = "txtTiempoS";
            this.txtTiempoS.Size = new System.Drawing.Size(120, 20);
            this.txtTiempoS.TabIndex = 39;
            // 
            // txtMasaS
            // 
            this.txtMasaS.DecimalPlaces = 10;
            this.txtMasaS.Location = new System.Drawing.Point(128, 9);
            this.txtMasaS.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtMasaS.Name = "txtMasaS";
            this.txtMasaS.Size = new System.Drawing.Size(120, 20);
            this.txtMasaS.TabIndex = 38;
            // 
            // btnCalcS
            // 
            this.btnCalcS.Location = new System.Drawing.Point(241, 300);
            this.btnCalcS.Name = "btnCalcS";
            this.btnCalcS.Size = new System.Drawing.Size(75, 23);
            this.btnCalcS.TabIndex = 37;
            this.btnCalcS.Text = "Calcular";
            this.btnCalcS.UseVisualStyleBackColor = true;
            this.btnCalcS.Click += new System.EventHandler(this.btnCalcS_Click);
            // 
            // txtErrorAS
            // 
            this.txtErrorAS.Location = new System.Drawing.Point(129, 271);
            this.txtErrorAS.Name = "txtErrorAS";
            this.txtErrorAS.ReadOnly = true;
            this.txtErrorAS.Size = new System.Drawing.Size(100, 20);
            this.txtErrorAS.TabIndex = 36;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(7, 272);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(92, 13);
            this.label33.TabIndex = 35;
            this.label33.Text = "Error aproximado: ";
            // 
            // txtIteracionesS
            // 
            this.txtIteracionesS.Location = new System.Drawing.Point(128, 242);
            this.txtIteracionesS.Name = "txtIteracionesS";
            this.txtIteracionesS.ReadOnly = true;
            this.txtIteracionesS.Size = new System.Drawing.Size(100, 20);
            this.txtIteracionesS.TabIndex = 30;
            // 
            // txtResultadoS
            // 
            this.txtResultadoS.Location = new System.Drawing.Point(128, 216);
            this.txtResultadoS.Name = "txtResultadoS";
            this.txtResultadoS.ReadOnly = true;
            this.txtResultadoS.Size = new System.Drawing.Size(100, 20);
            this.txtResultadoS.TabIndex = 29;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(7, 245);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(114, 13);
            this.label25.TabIndex = 18;
            this.label25.Text = "Las iteraciones fueron:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 219);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(59, 13);
            this.label26.TabIndex = 28;
            this.label26.Text = "El valor es:";
            // 
            // btnCalcularS
            // 
            this.btnCalcularS.Location = new System.Drawing.Point(440, 241);
            this.btnCalcularS.Name = "btnCalcularS";
            this.btnCalcularS.Size = new System.Drawing.Size(75, 23);
            this.btnCalcularS.TabIndex = 27;
            this.btnCalcularS.Text = "Calcular";
            this.btnCalcularS.UseVisualStyleBackColor = true;
            this.btnCalcularS.Click += new System.EventHandler(this.btnCalcularS_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 104);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(77, 13);
            this.label27.TabIndex = 25;
            this.label27.Text = "Error estimado:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 75);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(57, 13);
            this.label28.TabIndex = 23;
            this.label28.Text = "Velocidad:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(6, 43);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(45, 13);
            this.label29.TabIndex = 21;
            this.label29.Text = "Tiempo:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(6, 11);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(36, 13);
            this.label30.TabIndex = 20;
            this.label30.Text = "Masa:";
            // 
            // txtC1B
            // 
            this.txtC1B.DecimalPlaces = 10;
            this.txtC1B.Location = new System.Drawing.Point(128, 133);
            this.txtC1B.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtC1B.Name = "txtC1B";
            this.txtC1B.Size = new System.Drawing.Size(120, 20);
            this.txtC1B.TabIndex = 24;
            // 
            // txtC2B
            // 
            this.txtC2B.DecimalPlaces = 10;
            this.txtC2B.Location = new System.Drawing.Point(128, 160);
            this.txtC2B.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtC2B.Name = "txtC2B";
            this.txtC2B.Size = new System.Drawing.Size(120, 20);
            this.txtC2B.TabIndex = 25;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 135);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "Valor de C1:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 162);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 13);
            this.label8.TabIndex = 27;
            this.label8.Text = "Valor de C2:";
            // 
            // txtCPF
            // 
            this.txtCPF.DecimalPlaces = 10;
            this.txtCPF.Location = new System.Drawing.Point(128, 128);
            this.txtCPF.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtCPF.Name = "txtCPF";
            this.txtCPF.Size = new System.Drawing.Size(120, 20);
            this.txtCPF.TabIndex = 42;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 130);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 13);
            this.label9.TabIndex = 44;
            this.label9.Text = "Valor de C:";
            // 
            // txtC1S
            // 
            this.txtC1S.DecimalPlaces = 10;
            this.txtC1S.Location = new System.Drawing.Point(128, 129);
            this.txtC1S.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtC1S.Name = "txtC1S";
            this.txtC1S.Size = new System.Drawing.Size(120, 20);
            this.txtC1S.TabIndex = 42;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 131);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 13);
            this.label10.TabIndex = 43;
            this.label10.Text = "Valor de C1:";
            // 
            // txtC2S
            // 
            this.txtC2S.DecimalPlaces = 10;
            this.txtC2S.Location = new System.Drawing.Point(128, 155);
            this.txtC2S.Maximum = new decimal(new int[] {
            32767,
            0,
            0,
            0});
            this.txtC2S.Name = "txtC2S";
            this.txtC2S.Size = new System.Drawing.Size(120, 20);
            this.txtC2S.TabIndex = 44;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 157);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 13);
            this.label11.TabIndex = 45;
            this.label11.Text = "Valor de C2:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(353, 382);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Calculadora de Métodos Numéricos";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtErrorEB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVelocidadB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTiempoB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMasaB)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtErrorEPF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVelocidadPF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTiempoPF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMasaPF)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtErrorES)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVelocidadS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTiempoS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMasaS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtC1B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtC2B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCPF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtC1S)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtC2S)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnCalcularB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtIteracionesB;
        private System.Windows.Forms.TextBox txtResultadoB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtIteracionesPF;
        private System.Windows.Forms.TextBox txtResultadoPF;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnCalcularPF;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox txtIteracionesS;
        private System.Windows.Forms.TextBox txtResultadoS;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button btnCalcularS;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtErrorAB;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtErrorAPF;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtErrorAS;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button btnCalcPF;
        private System.Windows.Forms.Button btnCalcS;
        private System.Windows.Forms.NumericUpDown txtMasaB;
        private System.Windows.Forms.NumericUpDown txtErrorEB;
        private System.Windows.Forms.NumericUpDown txtVelocidadB;
        private System.Windows.Forms.NumericUpDown txtTiempoB;
        private System.Windows.Forms.NumericUpDown txtErrorEPF;
        private System.Windows.Forms.NumericUpDown txtVelocidadPF;
        private System.Windows.Forms.NumericUpDown txtTiempoPF;
        private System.Windows.Forms.NumericUpDown txtMasaPF;
        private System.Windows.Forms.NumericUpDown txtErrorES;
        private System.Windows.Forms.NumericUpDown txtVelocidadS;
        private System.Windows.Forms.NumericUpDown txtTiempoS;
        private System.Windows.Forms.NumericUpDown txtMasaS;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown txtC2B;
        private System.Windows.Forms.NumericUpDown txtC1B;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown txtCPF;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown txtC2S;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown txtC1S;
    }
}

